#include "Arduino.h"
#include "Magnet.h"
