#include "Arduino.h"
#include "Arm.h"

Arm::Arm() {//default constructor
}

Arm::armExtend() {

}

Arm::armRetract() {

}

bool Arm::hitBackWall() {

}
