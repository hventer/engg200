#ifndef Arm_h
#define Arm_h

#include "Arduino.h"

class Arm {
  	private:
        int armEnable; //motorControler outputA green
        int armInput1; //motorControler outputB yellow
        int armInput2; //pin for arm motor

	public:
		Arm();

		virtual void armExtend();
    virtual void armRetract();
    virtual bool hitBackWall();
    virtual void grabStart();
    virtual void grabStop();
};

class ArmRollers: public Arm {
public:
  ArmRollers();
  void armExtend();
  void armRetract();
  bool hitBackWall();
  void grabStart();
  void grabStop();
};

class ArmMagnet: public Arm {
public:
  ArmRollers();
  void armExtend();
  void armRetract();
  bool hitBackWall();
  void grabStart();
  void grabStop();
};


#endif
